public interface ArteMarcial {

}
