public interface JiuJitsu {
    public double MataLeao();
}
