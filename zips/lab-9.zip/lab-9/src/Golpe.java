public class Golpe {
    public String nome;
    public double forca;

    public Golpe(String nome, double forca) {
        this.nome = nome;
        this.forca = forca;
    }
}
