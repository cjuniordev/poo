public interface Fogo {
    public double atirar();
}
