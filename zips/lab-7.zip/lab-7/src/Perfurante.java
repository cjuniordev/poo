public interface Perfurante {
    public double perfura();
}
