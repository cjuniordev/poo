public interface Karate {
    public double MaeHijiAte();
}
