public class Proprietario
{
    private String nome;
    private Carro meuCarro;


    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public Carro getMeuCarro()
    {
        return meuCarro;
    }

    public void setMeuCarro(Carro meuCarro)
    {
        this.meuCarro = meuCarro;
    }
}
