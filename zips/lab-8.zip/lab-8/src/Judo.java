public interface Judo {
    public double UchiMata();
}
